function Data() {
    var userName = document.getElementById("box03").value; 
   document.getElementById("box03").value = "";

document.getElementById ("final").innerHTML = "<h4> Name: "+userName+" </h4>"}