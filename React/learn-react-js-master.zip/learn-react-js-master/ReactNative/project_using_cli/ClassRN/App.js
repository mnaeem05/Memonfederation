import React from 'react';
import RootApp from './src/root/root';

export default RootApp;